import type { Expense } from "../../types/expense";
import "./ExpenseList.css";

type Props = {
    expenses: Expense[];
    onDelete: (id: string) => void;
};

function fmtMoney(n: number) {
    return n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export default function ExpenseList({ expenses, onDelete }: Props) {
    if (expenses.length === 0) return <div className="empty">No expenses yet.</div>;

    return (
        <div className="list">
            {expenses.map((e) => (
                <div className="expenseRow" key={e.id}>
                    <div className="left">
                        <div className="main">
                            <span className="amt">₱{fmtMoney(Number(e.amount))}</span>
                            <span className="cat">
                                {e.category}
                                {e.subcategory ? ` / ${e.subcategory}` : ""}
                            </span>
                        </div>
                        <div className="meta">
                            <span>{e.date}</span>
                            {e.notes ? <span>• {e.notes}</span> : null}
                            {e.paymentMethod ? <span>• {e.paymentMethod}</span> : null}
                        </div>
                    </div>

                    <button className="danger" onClick={() => onDelete(e.id)}>
                        Delete
                    </button>
                </div>
            ))}
        </div>
    );
}
