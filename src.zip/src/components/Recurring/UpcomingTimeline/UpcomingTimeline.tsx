import type { RecurringItem } from "../../../types/recurring";
import { formatDateLabel } from "../../../lib/recurring";
import "./UpcomingTimeline.css";

type Props = {
    items: RecurringItem[];
    onEdit: (item: RecurringItem) => void;
};

export default function UpcomingTimeline({ items, onEdit }: Props) {
    const sorted = items.slice().sort((a, b) => a.nextDueDate.localeCompare(b.nextDueDate));

    const groups = new Map<string, RecurringItem[]>();
    for (const it of sorted) {
        const k = it.nextDueDate;
        groups.set(k, [...(groups.get(k) || []), it]);
    }

    const dates = [...groups.keys()].slice(0, 20);

    if (sorted.length === 0) {
        return <div className="empty">No upcoming items match your filters.</div>;
    }

    return (
        <div className="timeline">
            {dates.map((d) => (
                <div key={d} className="day">
                    <div className="dayTitle">{formatDateLabel(d)}</div>

                    <div className="dayList">
                        {(groups.get(d) || []).map((it) => (
                            <div className="item" key={it.id}>
                                <div className="left">
                                    <div className="nameRow">
                                        <div className="name">{it.name}</div>
                                        <span className={`badge ${it.status}`}>{it.status}</span>
                                    </div>
                                    <div className="meta">
                                        <span>₱{Number(it.amount).toFixed(2)}</span>
                                        <span>• {it.frequency}</span>
                                        <span>• {it.paymentMethod}</span>
                                        <span>
                                            • {it.category}
                                            {it.subcategory ? ` / ${it.subcategory}` : ""}
                                        </span>
                                        <span>• Auto-add {it.autoAddExpense ? "ON" : "OFF"}</span>
                                    </div>
                                </div>

                                {/* ✅ Edit / quick actions trigger */}
                                <button
                                    type="button"
                                    className="dots"
                                    aria-label={`Edit ${it.name}`}
                                    title="Edit recurring"
                                    onClick={() => onEdit(it)}
                                >
                                    ⋯
                                </button>
                            </div>
                        ))}
                    </div>
                </div>
            ))}
        </div>
    );
}
