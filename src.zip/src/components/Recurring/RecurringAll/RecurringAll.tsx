import type { RecurringItem } from "../../../types/recurring";
import { monthlyEquivalent } from "../../../lib/recurring";
import "./RecurringAll.css";

type Props = {
    items: RecurringItem[];
    onEdit: (item: RecurringItem) => void;
};


export default function RecurringAll({ items, onEdit }: Props) {
    if (items.length === 0) return <div className="empty">No items match your filters.</div>;

    const sorted = items.slice().sort((a, b) => a.category.localeCompare(b.category));

    return (
        <div className="all">
            {sorted.map((it) => (
                <div className="card" key={it.id}>
                    <div className="top">
                        <div>
                            <div className="name">{it.name}{it.merchant ? ` — ${it.merchant}` : ""}</div>
                            <div className="sub">
                                {it.category}{it.subcategory ? ` / ${it.subcategory}` : ""} • {it.paymentMethod}
                            </div>
                        </div>
                        <div className="amt">₱{Number(it.amount).toFixed(2)}</div>
                    </div>

                    <div className="grid">
                        <div><span className="k">Frequency</span><span className="v">{it.frequency}</span></div>
                        <div><span className="k">Start</span><span className="v">{it.startDate}</span></div>
                        <div><span className="k">Next due</span><span className="v">{it.nextDueDate}</span></div>
                        <div><span className="k">Status</span><span className="v">{it.status}</span></div>
                        <div><span className="k">Monthly Eq.</span><span className="v">₱{monthlyEquivalent(it).toFixed(2)}</span></div>
                        <div><span className="k">Auto-add</span><span className="v">{it.autoAddExpense ? "ON" : "OFF"}</span></div>
                    </div>

                    <button
                        type="button"
                        className="iconBtn"
                        aria-label={`Edit ${it.name}`}
                        title="Edit recurring"
                        onClick={() => onEdit(it)}
                    >
                        <PencilIcon />
                    </button>


                    {it.notes ? <div className="notes">Notes: {it.notes}</div> : null}
                </div>
            ))}
        </div>
    );
}

function PencilIcon() {
    return (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" role="presentation">
            <path d="M12 20h9" />
            <path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4 11.5-11.5Z" />
        </svg>
    );
}
