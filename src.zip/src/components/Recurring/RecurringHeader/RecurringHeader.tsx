import type { RecurringItem } from "../../../types/recurring";
import { inNextDays, monthlyEquivalent } from "../../../lib/recurring";
import "./RecurringHeader.css";

type Props = { items: RecurringItem[] };

export default function RecurringHeader({ items }: Props) {
    const active = items.filter((i) => i.status !== "cancelled");

    const monthlyEq = active.reduce((sum, i) => sum + monthlyEquivalent(i), 0);

    const dueNext7 = active
        .filter((i) => inNextDays(i.nextDueDate, 7) && i.status !== "paused")
        .reduce((sum, i) => sum + Number(i.amount || 0), 0);

    const upcoming = active
        .filter((i) => i.status !== "paused")
        .slice()
        .sort((a, b) => a.nextDueDate.localeCompare(b.nextDueDate))[0];

    return (
        <div className="recHeader">
            <div className="row">
                <div className="metric">
                    <div className="k">Recurring spend (Monthly Eq.)</div>
                    <div className="v">₱{monthlyEq.toFixed(2)}</div>
                </div>

                <div className="metric">
                    <div className="k">Due in next 7 days</div>
                    <div className="v">₱{dueNext7.toFixed(2)}</div>
                </div>

                <div className="metric span2">
                    <div className="k">Upcoming next bill</div>
                    <div className="v">
                        {upcoming ? (
                            <>
                                <span className="bold">{upcoming.name}</span> — {upcoming.nextDueDate} — ₱
                                {Number(upcoming.amount).toFixed(2)}
                            </>
                        ) : (
                            "—"
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
