import "./RecurringTabs.css";

export type RecTab = "upcoming" | "all" | "insights" | "rules";

type Props = { tab: RecTab; onChange: (t: RecTab) => void };

export default function RecurringTabs({ tab, onChange }: Props) {
    return (
        <div className="tabs">
            <button className={tab === "upcoming" ? "on" : ""} onClick={() => onChange("upcoming")}>Upcoming</button>
            <button className={tab === "all" ? "on" : ""} onClick={() => onChange("all")}>All</button>
            <button className={tab === "insights" ? "on" : ""} onClick={() => onChange("insights")}>Insights</button>
            <button className={tab === "rules" ? "on" : ""} onClick={() => onChange("rules")}>Rules / Automation</button>
        </div>
    );
}
