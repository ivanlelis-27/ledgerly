import type { PaymentMethod } from "../../../types/expense";
import type { RecurringFilters, RecurringFrequency, RecurringStatus } from "../../../types/recurring";
import "./RecurringFilters.css";

type Props = {
    filters: RecurringFilters;
    categories: string[];
    onChange: (next: RecurringFilters) => void;
    onAdd: () => void;
};

const statusOptions: Array<RecurringStatus | "all"> = ["all", "active", "trial", "paused", "cancelled"];
const freqOptions: Array<RecurringFrequency | "all"> = ["all", "weekly", "monthly", "quarterly", "yearly", "custom"];
const payOptions: Array<PaymentMethod | "all"> = ["all", "cash", "gcash", "card", "bank", "other"];

export default function RecurringFilters({ filters, categories, onChange, onAdd }: Props) {
    return (
        <div className="recFilters">
            <div className="top">
                <input
                    className="search"
                    placeholder='Search (e.g., "netflix", "globe", "gym")'
                    value={filters.q}
                    onChange={(e) => onChange({ ...filters, q: e.target.value })}
                />

                <div className="actions">
                    <select className="select" value={filters.sort} onChange={(e) => onChange({ ...filters, sort: e.target.value as any })}>
                        <option value="nextDue">Next due date</option>
                        <option value="monthlyEq">Highest monthly equivalent</option>
                        <option value="updated">Recently updated</option>
                    </select>

                    <button className="primary" onClick={onAdd}>Add recurring</button>
                </div>
            </div>

            <div className="chips">
                <select className="chip" value={filters.status} onChange={(e) => onChange({ ...filters, status: e.target.value as any })}>
                    {statusOptions.map((s) => <option key={s} value={s}>Status: {s}</option>)}
                </select>

                <select className="chip" value={filters.frequency} onChange={(e) => onChange({ ...filters, frequency: e.target.value as any })}>
                    {freqOptions.map((f) => <option key={f} value={f}>Frequency: {f}</option>)}
                </select>

                <select className="chip" value={filters.paymentMethod} onChange={(e) => onChange({ ...filters, paymentMethod: e.target.value as any })}>
                    {payOptions.map((p) => <option key={p} value={p}>Payment: {p}</option>)}
                </select>

                <select className="chip" value={filters.category} onChange={(e) => onChange({ ...filters, category: e.target.value })}>
                    <option value="all">Category: all</option>
                    {categories.map((c) => <option key={c} value={c}>Category: {c}</option>)}
                </select>

                {/* placeholders for later */}
                <button className="ghost" disabled>Bulk actions</button>
                <button className="ghost" disabled>Calendar</button>
            </div>
        </div>
    );
}
