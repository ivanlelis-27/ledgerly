export type SalaryProfile = {
    monthlyIncome: number;     // in PHP
    updatedAt: number;
};