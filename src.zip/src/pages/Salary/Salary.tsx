import { useMemo, useState, useEffect } from "react";
import styles from "./Salary.module.css";
import { useExpenses } from "../../lib/useExpenses";
import { useSalaryProfile } from "../../lib/useSalaryProfile";
import { upsertSalaryProfile } from "../../lib/data";

function isoToday(): string {
    const d = new Date();
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, "0");
    const dd = String(d.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
}

function isoStartOfMonth(): string {
    const d = new Date();
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, "0");
    return `${yyyy}-${mm}-01`;
}

function daysInMonth(): number {
    const d = new Date();
    return new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
}

function dayOfMonth(): number {
    return new Date().getDate();
}

export default function Salary() {
    const { expenses } = useExpenses();
    const { profile, error, refetch } = useSalaryProfile();

    const [incomeInput, setIncomeInput] = useState<string>(
        profile?.monthlyIncome ? String(profile.monthlyIncome) : ""
    );

    // ✅ keep input in sync when bootstrap updates local salary
    useEffect(() => {
        setIncomeInput(profile?.monthlyIncome ? String(profile.monthlyIncome) : "");
    }, [profile?.monthlyIncome]);

    const monthSpent = useMemo(() => {
        const start = isoStartOfMonth();
        const end = isoToday();
        return expenses
            .filter((e) => e.date >= start && e.date <= end)
            .reduce((sum, e) => sum + Number(e.amount || 0), 0);
    }, [expenses]);

    const income = Number(profile?.monthlyIncome || 0);
    const remaining = Math.max(0, income - monthSpent);

    const spentPct = income > 0 ? (monthSpent / income) * 100 : 0;

    const avgPerDay = useMemo(() => {
        const d = Math.max(1, dayOfMonth());
        return monthSpent / d;
    }, [monthSpent]);

    const projectedSpend = useMemo(() => avgPerDay * daysInMonth(), [avgPerDay]);
    const projectedSavings = income > 0 ? income - projectedSpend : 0;

    async function onSave() {
        const n = Number(incomeInput);
        if (!Number.isFinite(n) || n < 0) {
            alert("Please enter a valid income amount.");
            return;
        }
        try {
            await upsertSalaryProfile(n);
            await refetch();
        } catch (err: unknown) {
            const message = err instanceof Error ? err.message : "Failed to save salary.";
            alert(message);
        }
    }

    return (
        <div className={styles.salaryPage}>
            <div className={styles.pageHead}>
                <h1 className={styles.title}>Salary</h1>
                <p className={styles.sub}>Set your monthly income to unlock spending & savings insights.</p>
                {error && <div style={{ color: "var(--danger, #dc2626)", fontSize: 13 }}>{error}</div>}
            </div>

            <div className={styles.salaryGrid}>
                <div className={styles.card}>
                    <div className={styles.cardTitle}>Monthly income</div>

                    <div className={styles.incomeRow}>
                        <div className={styles.currency}>₱</div>
                        <input
                            className={styles.incomeInput}
                            inputMode="numeric"
                            placeholder="30000"
                            value={incomeInput}
                            onChange={(e) => setIncomeInput(e.target.value)}
                        />
                        <button className={styles.primaryBtn} type="button" onClick={onSave}>
                            Save
                        </button>
                    </div>

                    <div className={styles.hint}>
                        Optional. Stored securely in your Ledgerly account. You can change it anytime.
                    </div>
                </div>

                <div className={styles.card}>
                    <div className={styles.cardTitle}>This month</div>

                    <div className={styles.metrics}>
                        <div className={styles.metric}>
                            <div className={styles.k}>Spent</div>
                            <div className={styles.v}>₱{monthSpent.toFixed(2)}</div>
                        </div>

                        <div className={styles.metric}>
                            <div className={styles.k}>Income</div>
                            <div className={styles.v}>{income > 0 ? `₱${income.toFixed(2)}` : "—"}</div>
                        </div>

                        <div className={styles.metric}>
                            <div className={styles.k}>Remaining</div>
                            <div className={styles.v}>{income > 0 ? `₱${remaining.toFixed(2)}` : "—"}</div>
                        </div>
                    </div>

                    <div className={styles.progressWrap}>
                        <div className={styles.progressHead}>
                            <span className="muted">% spent</span>
                            <span className="muted">{income > 0 ? `${spentPct.toFixed(0)}%` : "—"}</span>
                        </div>

                        <div className={styles.barTrack}>
                            <div
                                className={styles.barFill}
                                style={{ width: `${Math.min(100, spentPct)}%` }}
                                aria-hidden="true"
                            />
                        </div>
                    </div>
                </div>

                <div className={styles.card}>
                    <div className={styles.cardTitleRow}>
                        <div className={styles.cardTitle}>Burn rate</div>

                        <div className={styles.infoWrap}>
                            <button type="button" className={styles.infoBtn} aria-label="What is burn rate?">
                                <InfoIcon />
                            </button>

                            <div className={styles.tooltip}>
                                Burn rate is your average daily spending this month.
                                <br />
                                <br />
                                It helps estimate how much you’ll spend by month-end if your current spending pace continues.
                            </div>
                        </div>
                    </div>

                    <div className={styles.bigStat}>₱{avgPerDay.toFixed(2)} / day</div>
                    <div className="muted">Projection: ₱{projectedSpend.toFixed(0)} this month</div>

                    <div className="muted" style={{ marginTop: 6 }}>
                        Projected savings: {income > 0 ? `₱${projectedSavings.toFixed(0)}` : "—"}
                    </div>
                </div>
            </div>
        </div>
    );
}

function InfoIcon() {
    return (
        <svg viewBox="0 0 24 24" role="presentation" fill="none" stroke="currentColor" strokeWidth="1.8">
            <circle cx="12" cy="12" r="9" />
            <line x1="12" y1="10.5" x2="12" y2="16" />
            <circle cx="12" cy="7.5" r="1" fill="currentColor" stroke="none" />
        </svg>
    );
}
