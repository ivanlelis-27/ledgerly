import { useState } from "react";
import { signIn } from "../../lib/auth";
import { Link, useNavigate } from "react-router-dom";
import "./Login.css";

export default function Login() {
    const nav = useNavigate();
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    async function onSubmit(e: React.FormEvent) {
        e.preventDefault();

        const { error } = await signIn(email, password);

        if (error) {
            alert(error.message);
            return;
        }

        nav("/dashboard");
    }


    return (
        <div className="authShell">
            <div className="authFrame">
                {/* LEFT */}
                <div className="authLeft">
                    <div className="brandRow">
                        <div className="brandMark" aria-hidden="true">
                            <span className="markDot" />
                            <span className="markDot" />
                            <span className="markDot" />
                        </div>
                        <div className="brandName">Ledgerly</div>
                    </div>

                    <div className="head">
                        <h1 className="title">Welcome back</h1>
                        <p className="sub">Log in to continue using Ledgerly.</p>
                    </div>

                    <div className="socialRow">
                        <button
                            type="button"
                            className="socialBtn"
                            onClick={() => alert("Google login later")}
                        >
                            <span className="socialIcon">G</span>
                            Continue with Google
                        </button>

                        <button
                            type="button"
                            className="socialBtn"
                            onClick={() => alert("Apple login later")}
                        >
                            <span className="socialIcon"></span>
                            Continue with Apple ID
                        </button>
                    </div>

                    <div className="divider">
                        <span className="line" />
                        <span className="or">or</span>
                        <span className="line" />
                    </div>

                    <form className="form" onSubmit={onSubmit}>
                        <div className="field">
                            <label>Email</label>
                            <input
                                type="email"
                                className="input"
                                placeholder="you@example.com"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                autoComplete="email"
                                required
                            />
                        </div>

                        <div className="field">
                            <label>Password</label>
                            <div className="pwRow">
                                <input
                                    type="password"
                                    className="input"
                                    placeholder="••••••••"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    autoComplete="current-password"
                                    required
                                />
                            </div>
                        </div>

                        <div className="belowRow">
                            <button
                                className="inlineLink"
                                type="button"
                                onClick={() => alert("Password reset flow later.")}
                            >
                                Forgot password?
                            </button>
                        </div>

                        <button className="primaryBtn" type="submit">
                            Log in
                        </button>
                    </form>

                    <div className="foot">
                        <span>New here?</span>{" "}
                        <Link className="link" to="/register">
                            Create an account
                        </Link>
                    </div>
                </div>

                {/* RIGHT (blank hero for now) */}
                <div className="authRight" aria-label="Hero panel">
                    <div className="heroMedia" aria-hidden="true">
                        <img className="heroImg" src="/hero2.png" alt="" />
                    </div>
                </div>
            </div>
        </div>
    );
}
