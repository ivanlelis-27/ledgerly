import { useMemo, useState } from "react";
import { expensesToCSV, downloadTextFile } from "../../lib/csv";
import type { Expense } from "../../types/expense";
import ExpenseList from "../../components/ExpenseList/ExpenseList";
import { Link } from "react-router-dom";
import { useExpenses } from "../../lib/useExpenses";
import { useRecurringItems } from "../../lib/useRecurringItems";
import { useUserSettings } from "../../lib/useUserSettings";
import { removeExpense } from "../../lib/data";
import "./Dashboard.css";

// ─── Local-time date helpers ──────────────────────────────────
// All helpers produce YYYY-MM-DD strings in the user's LOCAL timezone.

function localIso(date: Date): string {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, "0");
    const d = String(date.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
}

/** Today in local time */
function localToday(): string {
    return localIso(new Date());
}

/** Local date N days ago (positive) or in future (negative) */
function localDaysOffset(offset: number): string {
    const d = new Date();
    d.setDate(d.getDate() + offset);
    return localIso(d);
}

/** First day of the current calendar month (local) */
function localMonthStart(): string {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-01`;
}

/** Last day of the current calendar month (local) */
function localMonthEnd(): string {
    const d = new Date();
    const lastDay = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(lastDay).padStart(2, "0")}`;
}

/**
 * Start of the current week in local time.
 * weekStart: "monday" (1), "sunday" (0), "saturday" (6)
 */
function localWeekStart(weekStartPref: string): string {
    const today = new Date();
    const dow = today.getDay(); // 0=Sun, 1=Mon … 6=Sat
    const startDow = weekStartPref === "monday" ? 1 : weekStartPref === "saturday" ? 6 : 0;
    let diff = dow - startDow;
    if (diff < 0) diff += 7;
    const start = new Date(today);
    start.setDate(today.getDate() - diff);
    return localIso(start);
}

/** Previous period start/end for delta comparison */
function prevPeriod(range: RangeKey, customStart: string, customEnd: string, weekStartPref: string): [string, string] {
    if (range === "today") {
        const prev = localDaysOffset(-1);
        return [prev, prev];
    }
    if (range === "week") {
        const ws = localWeekStart(weekStartPref);
        const wsDate = new Date(ws + "T00:00:00");
        const prevEnd = new Date(wsDate);
        prevEnd.setDate(wsDate.getDate() - 1);
        const prevStart = new Date(prevEnd);
        prevStart.setDate(prevEnd.getDate() - 6);
        return [localIso(prevStart), localIso(prevEnd)];
    }
    if (range === "month") {
        const now = new Date();
        const prevMonthEnd = new Date(now.getFullYear(), now.getMonth(), 0);
        const prevMonthStart = new Date(prevMonthEnd.getFullYear(), prevMonthEnd.getMonth(), 1);
        return [localIso(prevMonthStart), localIso(prevMonthEnd)];
    }
    // custom: mirror the same duration before customStart
    const start = new Date(customStart + "T00:00:00");
    const end = new Date(customEnd + "T00:00:00");
    const days = Math.round((end.getTime() - start.getTime()) / 86_400_000);
    const prevEnd = new Date(start);
    prevEnd.setDate(start.getDate() - 1);
    const prevStart = new Date(prevEnd);
    prevStart.setDate(prevEnd.getDate() - days);
    return [localIso(prevStart), localIso(prevEnd)];
}

/** Human-readable date range label */
function rangeLabel(range: RangeKey, start: string, end: string): string {
    const fmt = (iso: string) => {
        const [y, m, d] = iso.split("-").map(Number);
        return new Date(y, (m || 1) - 1, d || 1)
            .toLocaleDateString(undefined, { month: "short", day: "numeric" });
    };
    if (range === "today") return `Today · ${fmt(start)}`;
    if (range === "week") return `${fmt(start)} – ${fmt(end)}`;
    if (range === "month") {
        const [y, m] = start.split("-").map(Number);
        return new Date(y, (m || 1) - 1, 1).toLocaleDateString(undefined, { month: "long", year: "numeric" });
    }
    return `${fmt(start)} – ${fmt(end)}`;
}

type RangeKey = "today" | "week" | "month" | "custom";

// ─── Component ────────────────────────────────────────────────
export default function Dashboard() {
    const [showAll, setShowAll] = useState(false);
    const [range, setRange] = useState<RangeKey>("month");
    const [customStart, setCustomStart] = useState(localMonthStart);
    const [customEnd, setCustomEnd] = useState(localToday);

    const { expenses: all, error: expensesError, refetch: refetchExpenses } = useExpenses();
    const { recurring: recurringAll, error: recurringError, refetch: refetchRecurring } = useRecurringItems();
    const { settings } = useUserSettings();
    const weekStartPref = settings.weekStart ?? "monday";

    // ── Compute current range start/end ──
    const [rangeStart, rangeEnd] = useMemo<[string, string]>(() => {
        if (range === "today") return [localToday(), localToday()];
        if (range === "week") return [localWeekStart(weekStartPref), localToday()];
        if (range === "month") return [localMonthStart(), localMonthEnd()];
        return [customStart, customEnd];
    }, [range, weekStartPref, customStart, customEnd]);

    // ── Filtered expenses ──
    const filtered = useMemo<Expense[]>(
        () => all.filter(e => e.date >= rangeStart && e.date <= rangeEnd),
        [all, rangeStart, rangeEnd]
    );

    const total = useMemo(() => filtered.reduce((s, e) => s + Number(e.amount || 0), 0), [filtered]);
    const txCount = filtered.length;

    const dayCount = useMemo(() => {
        const s = new Date(rangeStart + "T00:00:00");
        const e = new Date(rangeEnd + "T00:00:00");
        return Math.max(1, Math.round((e.getTime() - s.getTime()) / 86_400_000) + 1);
    }, [rangeStart, rangeEnd]);

    const avgPerDay = total / dayCount;

    const biggest = useMemo(() => {
        if (!filtered.length) return null;
        return filtered.reduce((max, e) => Number(e.amount) > Number(max.amount) ? e : max, filtered[0]);
    }, [filtered]);

    // ── Previous period delta ──
    const lastRangeTotal = useMemo(() => {
        const [ps, pe] = prevPeriod(range, customStart, customEnd, weekStartPref);
        return all.filter(e => e.date >= ps && e.date <= pe)
            .reduce((s, e) => s + Number(e.amount || 0), 0);
    }, [all, range, customStart, customEnd, weekStartPref]);

    const delta = total - lastRangeTotal;
    const deltaPct = lastRangeTotal > 0 ? (delta / lastRangeTotal) * 100 : null;

    // ── Top categories ──
    const topCategories = useMemo(() => {
        const map = new Map<string, number>();
        for (const e of filtered) map.set(e.category, (map.get(e.category) || 0) + Number(e.amount || 0));
        return [...map.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5);
    }, [filtered]);

    // ── Upcoming recurring (next 7 days, local) ──
    const today = localToday();
    const in7 = localDaysOffset(7);
    const upcomingRecurring = useMemo(
        () => recurringAll
            .filter(r => r.status !== "cancelled")
            .filter(r => r.nextDueDate >= today && r.nextDueDate <= in7)
            .sort((a, b) => a.nextDueDate.localeCompare(b.nextDueDate))
            .slice(0, 6),
        [recurringAll, today, in7]
    );

    // ── Handlers ──
    async function handleDelete(id: string) {
        try {
            await removeExpense(id);
            await refetchExpenses();
        } catch (err: unknown) {
            window.alert(err instanceof Error ? err.message : "Failed to delete expense.");
        }
    }

    function exportCSV() {
        downloadTextFile(`ledgerly-${range}.csv`, expensesToCSV(filtered));
    }

    function fmtMoney(n: number) {
        return n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }

    function fmtShort(iso: string) {
        const [y, m, d] = iso.split("-").map(Number);
        return new Date(y, (m || 1) - 1, d || 1).toLocaleDateString(undefined, { month: "short", day: "2-digit" });
    }

    const currentLabel = rangeLabel(range, rangeStart, rangeEnd);

    return (
        <div className="dash">

            {/* ── Header ── */}
            <div className="headerRow">
                <div>
                    <h1 className="title">Dashboard</h1>
                    <div className="subtitle">Track your spending across time</div>
                    {expensesError && <div style={{ color: "var(--danger, #dc2626)", fontSize: 13 }}>{expensesError}</div>}
                    {recurringError && <div style={{ color: "var(--danger, #dc2626)", fontSize: 13 }}>{recurringError}</div>}
                </div>

                <div className="controls">
                    {/* Range picker */}
                    <div className="rangeBlock">
                        <div className="seg">
                            {(["today", "week", "month", "custom"] as RangeKey[]).map(r => (
                                <button
                                    key={r}
                                    className={range === r ? "on" : ""}
                                    onClick={() => setRange(r)}
                                >
                                    {r.charAt(0).toUpperCase() + r.slice(1)}
                                </button>
                            ))}
                        </div>

                        {range === "custom" ? (
                            <div className="customDates">
                                <input
                                    type="date"
                                    className="dateInput"
                                    value={customStart}
                                    max={customEnd}
                                    onChange={e => setCustomStart(e.target.value)}
                                />
                                <span className="dateSep">→</span>
                                <input
                                    type="date"
                                    className="dateInput"
                                    value={customEnd}
                                    min={customStart}
                                    onChange={e => setCustomEnd(e.target.value)}
                                />
                            </div>
                        ) : (
                            <div className="rangeLabel">{currentLabel}</div>
                        )}
                    </div>

                    <div className="controlActions">
                        <button className="ghost" onClick={exportCSV}>Export CSV</button>
                        <button className="ghost" onClick={() => { void refetchExpenses(); void refetchRecurring(); }}>↺ Refresh</button>
                    </div>
                </div>
            </div>

            {/* ── Summary cards ── */}
            <div className="summary">
                <div className="summaryCard">
                    <div className="kLabel">Total spent</div>
                    <div className="kValue">₱{fmtMoney(total)}</div>
                    <div className="kSub">
                        {deltaPct === null ? (
                            <span className="muted">No previous data</span>
                        ) : (
                            <span className={delta >= 0 ? "up" : "down"}>
                                {delta >= 0 ? "▲" : "▼"} ₱{fmtMoney(Math.abs(delta))} ({Math.abs(deltaPct).toFixed(1)}%)
                                <span className="muted"> vs prev period</span>
                            </span>
                        )}
                    </div>
                </div>

                <div className="summaryCard">
                    <div className="kLabel">Transactions</div>
                    <div className="kValue">{txCount}</div>
                    <div className="kSub">
                        <span className="muted">Avg/day: ₱{fmtMoney(avgPerDay)}</span>
                    </div>
                </div>

                <div className="summaryCard">
                    <div className="kLabel">Biggest expense</div>
                    <div className="kValue">{biggest ? `₱${fmtMoney(Number(biggest.amount))}` : "—"}</div>
                    <div className="kSub">
                        {biggest ? (
                            <span className="muted">
                                {biggest.category}{biggest.subcategory ? ` / ${biggest.subcategory}` : ""}
                            </span>
                        ) : (
                            <span className="muted">No data</span>
                        )}
                    </div>
                </div>
            </div>

            {/* ── Main grid ── */}
            <div className="grid">
                <div className="leftCol">
                    {/* Top spends */}
                    <div className="card topSpendsCard">
                        <div className="cardTitle">Top spending categories</div>

                        {topCategories.length === 0 ? (
                            <div className="empty">No expenses in this period.</div>
                        ) : (
                            <div className="topList">
                                {topCategories.map(([name, amt]) => {
                                    const pct = total > 0 ? (amt / total) * 100 : 0;
                                    return (
                                        <div className="topBarRow" key={name}>
                                            <div className="topBarHead">
                                                <span className="topName">{name}</span>
                                                <span className="topAmt">₱{fmtMoney(amt)}</span>
                                            </div>
                                            <div className="barTrack">
                                                <div className="barFill" style={{ width: `${Math.min(100, pct)}%` }} />
                                            </div>
                                            <div className="barMeta">
                                                <span className="muted">{pct.toFixed(0)}% of total</span>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        )}
                    </div>

                    {/* Upcoming recurring */}
                    <div className="card">
                        <div className="cardTitleRow">
                            <div className="cardTitle">Upcoming (next 7 days)</div>
                            <Link className="miniLink" to="/recurring">View all →</Link>
                        </div>

                        {upcomingRecurring.length === 0 ? (
                            <div className="empty">No upcoming recurring bills.</div>
                        ) : (
                            <div className="upList">
                                {upcomingRecurring.map(r => (
                                    <div className="upRow" key={r.id}>
                                        <div className="upMain">
                                            <div className="upName">{r.name}</div>
                                            <div className="upMeta">
                                                <span className="pill">{r.paymentMethod}</span>
                                                <span className="dot">•</span>
                                                <span className="muted">{fmtShort(r.nextDueDate)}</span>
                                            </div>
                                        </div>
                                        <div className="upAmt">₱{fmtMoney(Number(r.amount))}</div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                </div>

                {/* Recent expenses */}
                <div className="card recentCard">
                    <div className="cardTitleRow">
                        <div className="cardTitle">Recent expenses</div>
                        <button className="miniLinkBtn" onClick={() => setShowAll(v => !v)}>
                            {showAll ? "Show less" : "View all →"}
                        </button>
                    </div>
                    <div className="cardBody">
                        <ExpenseList
                            expenses={showAll ? filtered : filtered.slice(0, 4)}
                            onDelete={handleDelete}
                        />
                    </div>
                </div>
            </div>
        </div>
    );
}
