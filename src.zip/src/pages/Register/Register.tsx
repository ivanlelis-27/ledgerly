import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { signUp } from "../../lib/auth";
import "./Register.css";

export default function Register() {
    const nav = useNavigate();
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [confirm, setConfirm] = useState("");
    const [agree, setAgree] = useState(true);

    async function onSubmit(e: React.FormEvent) {
        e.preventDefault();

        if (password !== confirm) {
            alert("Passwords do not match.");
            return;
        }

        const { error } = await signUp(email, password, name);

        if (error) {
            alert(error.message);
            return;
        }

        // If email confirmations are enabled, user may need to confirm first.
        // For now, just route them to login.
        nav("/login");
    }

    return (
        <div className="authShell">
            <div className="authFrame">
                {/* LEFT */}
                <div className="authLeft">
                    <div className="brandRow">
                        <div className="brandMark" aria-hidden="true">
                            {/* simple mark placeholder */}
                            <span className="markDot" />
                            <span className="markDot" />
                            <span className="markDot" />
                        </div>
                        <div className="brandName">Ledgerly</div>
                    </div>

                    <div className="head">
                        <h1 className="title">Get Started Now</h1>
                        <p className="sub">Track expenses, recurring bills, and build clarity — fast.</p>
                    </div>

                    <div className="socialRow">
                        <button
                            type="button"
                            className="socialBtn"
                            onClick={() => alert("Google sign up later")}
                        >
                            <span className="socialIcon">G</span>
                            Sign up with Google
                        </button>

                        <button
                            type="button"
                            className="socialBtn"
                            onClick={() => alert("Apple sign up later")}
                        >
                            <span className="socialIcon"></span>
                            Sign up with Apple ID
                        </button>
                    </div>

                    <div className="divider">
                        <span className="line" />
                        <span className="or">or</span>
                        <span className="line" />
                    </div>

                    <form className="form" onSubmit={onSubmit}>
                        <div className="field">
                            <label>Name</label>
                            <input
                                className="input"
                                placeholder="Ivan"
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                autoComplete="name"
                                required
                            />
                        </div>

                        <div className="field">
                            <label>Email</label>
                            <input
                                type="email"
                                className="input"
                                placeholder="you@example.com"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                autoComplete="email"
                                required
                            />
                        </div>

                        <div className="field">
                            <label>Password</label>
                            <input
                                type="password"
                                className="input"
                                placeholder="••••••••"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                autoComplete="new-password"
                                required
                            />
                        </div>

                        <div className="field">
                            <label>Confirm password</label>
                            <input
                                type="password"
                                className="input"
                                placeholder="••••••••"
                                value={confirm}
                                onChange={(e) => setConfirm(e.target.value)}
                                autoComplete="new-password"
                                required
                            />
                        </div>

                        <label className="agree">
                            <input
                                type="checkbox"
                                checked={agree}
                                onChange={(e) => setAgree(e.target.checked)}
                            />
                            <span>
                                I agree to the{" "}
                                <button
                                    type="button"
                                    className="inlineLink"
                                    onClick={() => alert("Terms later")}
                                >
                                    Terms
                                </button>{" "}
                                &{" "}
                                <button
                                    type="button"
                                    className="inlineLink"
                                    onClick={() => alert("Privacy later")}
                                >
                                    Privacy
                                </button>
                            </span>
                        </label>

                        <button className="primaryBtn" type="submit">
                            Sign Up
                        </button>
                    </form>

                    <div className="foot">
                        <span>Already have an account?</span>{" "}
                        <Link className="link" to="/login">
                            Sign In
                        </Link>
                    </div>
                </div>

                {/* RIGHT (blank hero for now) */}
                <div className="authRight" aria-label="Hero panel">
                    {/* image slot (leave empty for now; you can add later) */}
                    <div className="heroMedia" aria-hidden="true">
                        <img className="heroImg" src="/hero.png" alt="" />
                    </div>
                </div>
            </div>
        </div>
    );
}
